/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;

/**
 *
 * @author jvila
 */
public class GenericRadarPanel extends JPanel implements RadarPanelInt {

    @Override
    public Rectangle2D getArea() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
